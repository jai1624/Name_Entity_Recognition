# Bio-Med-Pretrained Model

This BIO-NER system can be used in various areas like a question-answering system or summarization system and many more areas of the domain-dependent NLP research.To develop the NER system to recognise and classify the Biomedical substances from the text.

## Additional Requirements For UI Part
gradio==3.35.2
pdfminer.six==20221105
spacy==3.5.2

## Pre-Trained Model biomedical-ner-all (Old Version)

Highlight 42 MEDICAL ENTITIES FROM PRE-TRAINED MODEL

## Pre-Trained Model biomedical-ner-all (Added FILTER METHOD)

Highlight Entites based on the specifity 

For example: Can Filter only Diagnostic Procedure instead of all the 42 labels
